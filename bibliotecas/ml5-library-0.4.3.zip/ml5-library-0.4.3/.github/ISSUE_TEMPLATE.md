<!--------------------------------------------
🌈DEAR BELOVED ML5 COMMUNITY MEMBER. WELCOME. 🌈
---------------------------------------------->

Dear ml5 community, 

I'm submitting a new issue. Please see the details below.



### → Step 1: Describe the issue 📝
> Did you find a bug? Want to suggest an idea for feature?




### → Step 2: Screenshots or Relevant Documentation 🖼
> Here's some helpful screenshots and/or documentation of the new feature 



### → Step 3: Share an example of the issue 🦄
> Here's some example code or a demonstration of  in https://github.com/ml5js/ml5-examples OR in the https://editor.p5js.org or codepen/jsfiddle/etc...






**Other relevant information, if applicable**

### → Describe your setup 🦄
> Here's some helpful information about my setup...

- **Web browser & version**:
- **Operating System**:
- **ml5 version you're using**:
- **Any additional notes**



<!--------------------------------------------
🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈
DEAR BELOVED ML5 COMMUNITY MEMBER. WELCOME.

BEFORE SUBMITTING AN ISSUE PLEASE MAKE
SURE TO SUBMIT THE RELEVANT INFORMATION
TO THE SECTIONS LISTED BELOW. 
HELP US HELP YOU BY PROVIDING ALL THE HELPFUL
INFORMATION THAT WILL ALLOW THE ML5 COMMUNITY
TO UNDERSTAND WHAT YOUR ISSUE SUBMISSION IS ABOUT.
WE WILL PRIORITIZE WELL DOCUMENTED ISSUES.

THANK YOU! MERCI! ABRIGADO! GRACIAS! DANKE!
🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈🌈
---------------------------------------------->

