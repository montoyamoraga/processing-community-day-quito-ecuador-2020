# Contributor Notes (External)

coming soon - notes for contributors