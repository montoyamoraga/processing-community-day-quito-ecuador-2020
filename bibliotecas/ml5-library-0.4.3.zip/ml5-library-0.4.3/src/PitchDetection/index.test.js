// Copyright (c) 2018 ml5
//
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT

const { pitchDetection } = ml5;

describe('pitchDetection', () => {
  let pitch;

  // beforeAll(async () => {
  // });

  // it('instantiates a pitchDetection', async () => {
  // });
});
